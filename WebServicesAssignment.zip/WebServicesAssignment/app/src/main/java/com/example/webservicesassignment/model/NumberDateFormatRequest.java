package com.example.webservicesassignment.model;

public class NumberDateFormatRequest {
    public int number;

    public NumberDateFormatRequest(int number) {
        this.number = number;
    }
}
