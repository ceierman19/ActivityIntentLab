package com.example.webservicesassignment.model;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.webservicesassignment.ServiceClient;
import com.google.gson.Gson;
import org.json.JSONException;
import org.json.JSONObject;

public class NumberDateFormatModel {
    public interface GetNumberDateFormatResponseHandler {
        void response(NumberDate numberDate);
        void error();
    }

    public void getNumberDateFormat(NumberDateFormatRequest request, GetNumberDateFormatResponseHandler handler) {
        Gson gson = new Gson();
        String json = gson.toJson(request);

        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, "https://mopsdev.bw.edu/~bkrupp/330/assignments/message.php", jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Gson gson = new Gson();
                NumberDate numberDate = gson.fromJson(response.toString(), NumberDate.class);
                handler.response(numberDate);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handler.error();
            }
        });
        ServiceClient client = ServiceClient.sharedServiceClient(null);
        client.addRequest(jsonRequest);
    }
}
