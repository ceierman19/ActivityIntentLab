package com.example.webservicesassignment;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.webservicesassignment.model.AuthRequest;
import com.example.webservicesassignment.model.NumberDate;
import com.example.webservicesassignment.model.NumberDateFormatModel;
import com.example.webservicesassignment.model.NumberDateFormatRequest;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ServiceClient.sharedServiceClient(getApplicationContext());
        setContentView(R.layout.activity_main);
    }

    public void save(View view) {
        EditText numberInput = findViewById(R.id.editTextNumber);
        int number = Integer.parseInt(numberInput.getText().toString());
        NumberDateFormatRequest requestObject = new NumberDateFormatRequest(number);
        NumberDateFormatModel model = new NumberDateFormatModel();
        model.getNumberDateFormat(requestObject, new NumberDateFormatModel.GetNumberDateFormatResponseHandler() {
            @Override
            public void response(NumberDate numberDate) {
                //TODO: toast that lets you know your request posted
            }

            @Override
            public void error() {
                //TODO: handle error
            }
        });
    }

    public void getLatestNumber(View view) {
        //TODO: remove Json from MainActivity
        AuthRequest.username = "ceierman19";
        AuthRequest.password = "changeme";
        JsonObjectRequest request = new AuthRequest(Request.Method.GET, "https://mopsdev.bw.edu/~ceierman19/csc330/architecture_template/www/rest.php/orders", null, new Response.Listener<JSONObject>() {
        //JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://mopsdev.bw.edu/~bkrupp/330/assignments/message.php", null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
//                int number = 0;
//                String date = "";
//
//                try {
//                    number = response.getInt("number");
//                    date = response.getString("date_received");
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//                TextView numberField = findViewById(R.id.textViewLatestNumber);
//                numberField.setText(String.format("Latest Number: %d", number));
//
//                TextView lastSavedField = findViewById(R.id.textViewLastSaved);
//                lastSavedField.setText(String.format("Last Saved: %s", date));

                TextView lastSavedField = findViewById(R.id.textViewLastSaved);
                lastSavedField.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley Error", error.toString());
                //TODO: handle error
            }
        });
        ServiceClient client = ServiceClient.sharedServiceClient(getApplicationContext());
        client.addRequest(request);
    }
}