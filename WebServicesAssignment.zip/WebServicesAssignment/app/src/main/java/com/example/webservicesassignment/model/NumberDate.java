package com.example.webservicesassignment.model;

public class NumberDate {
    public String number;
    public String date_received;

    public NumberDate(String date, String date_received) {
        this.number = number;
        this.date_received = date_received;
    }
}
